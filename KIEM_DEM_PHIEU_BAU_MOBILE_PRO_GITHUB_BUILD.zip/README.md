# KIỂM ĐẾM PHIẾU BẦU MOBILE PRO

Ứng dụng Flutter dành cho Android.

## Build APK online

1. Mở **Actions**.
2. Chọn **Build Android APK**.
3. Chọn **Run workflow**.
4. Sau khi hoàn tất, tải APK tại phần **Artifacts**.

Tệp APK sau khi build:

`KIEM_DEM_PHIEU_BAU_MOBILE_PRO.apk`

Workflow đã được cấu hình trong:

`.github/workflows/build-apk.yml`
